function [state, lambda] = UpdateState(state, P, lambda0, lambda1);

% Delete this
state = 0;
lambda = lambda0;

return;