function u = SteadyProbability(P);

% Delete this
u = [1;0];

return;