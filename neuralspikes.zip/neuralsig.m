function varargout = neuralsig(varargin)
% NEURALSIG M-file for neuralsig.fig
%      NEURALSIG, by itself, creates a new NEURALSIG or raises the existing
%      singleton*.
%
%      H = NEURALSIG returns the handle to a new NEURALSIG or the handle to
%      the existing singleton*.
%
%      NEURALSIG('CALLBACK',hObject,eventData,handles,...) calls the local
%      function named CALLBACK in NEURALSIG.M with the given input arguments.
%
%      NEURALSIG('Property','Value',...) creates a new NEURALSIG or raises the
%      existing singleton*.  Starting from the left, property value pairs are
%      applied to the GUI before neuralsig_OpeningFunction gets called.  An
%      unrecognized property name or invalid value makes property application
%      stop.  All inputs are passed to neuralsig_OpeningFcn via varargin.
%
%      *See GUI Options on GUIDE's Tools menu.  Choose "GUI allows only one
%      instance to run (singleton)".
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Copyright 2002-2003 The MathWorks, Inc.

% EditP01 the above text to modify the response to help neuralsig

% Last Modified by GUIDE v2.5 21-Apr-2008 00:39:25

% Begin initialization code - DO NOT EDITP01
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @neuralsig_OpeningFcn, ...
                   'gui_OutputFcn',  @neuralsig_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDITP01


% --- Executes just before neuralsig is made visible.
function neuralsig_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to neuralsig (see VARARGIN)

% Choose default command line output for neuralsig
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes neuralsig wait for user response (see UIRESUME)
% uiwait(handles.figure1);

set(gcf, 'CurrentAxes', handles.AxesNeuralSig); 
axis off;



% set(gcf, 'CurrentAxes', handles.AxesBrain);
% title(''); cla; axis off; legend off; hold off;
% imshow(imread('Brain.tif'));



set(handles.ButtonStartStop, 'Value', 0);

handles.P = [.5 .5; .5 .5];
handles.lambda0 = 4;
handles.lambda1 = 15;

set(handles.EditP00, 'String', num2str(handles.P(1,1)));
set(handles.EditP01, 'String', num2str(handles.P(1,2)));
set(handles.EditP10, 'String', num2str(handles.P(2,1)));
set(handles.EditP11, 'String', num2str(handles.P(2,2)));
set(handles.EditLambda0, 'String', num2str(handles.lambda0));
set(handles.EditLambda1, 'String', num2str(handles.lambda1));
clc;

% Initialize WindowLength slider
% set(handles.SliderAniSpeed, 'Min', .99);
% set(handles.SliderAniSpeed, 'Max', .01);
% set(handles.SliderAniSpeed, 'SliderStep', [1/(.99-.01) 0.1]);
% set(handles.SliderAniSpeed, 'Value', .5);

handles.AniSpeed = get(handles.SliderAniSpeed, 'Value');

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = neuralsig_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;



%-----------------------------------------------------------%
function SliderAniSpeed_Callback(hObject, eventdata, handles)
%-----------------------------------------------------------%

handles.AniSpeed = get(handles.SliderAniSpeed, 'Value');

% Update handles structure
guidata(hObject, handles);

RunCicle(hObject, eventdata, handles);

%------------------------------------------------------------%
function ButtonStartStop_Callback(hObject, eventdata, handles)
%------------------------------------------------------------%

RunCicle(hObject, eventdata, handles);



%----------------------------------------------------%
function EditP00_Callback(hObject, eventdata, handles)
%----------------------------------------------------%

handles.P(1,1) = str2num(get(handles.EditP00, 'String'));
handles.P(1,2) = 1 - handles.P(1,1);
set(handles.EditP01, 'String', num2str(handles.P(1,2)));

% Update handles structure
guidata(hObject, handles);

RunCicle(hObject, eventdata, handles);

return;

%----------------------------------------------------%
function EditP01_Callback(hObject, eventdata, handles)
%----------------------------------------------------%

handles.P(1,2) = str2num(get(handles.EditP01, 'String'));
handles.P(1,1) = 1 - handles.P(1,2);
set(handles.EditP00, 'String', num2str(handles.P(1,1)));

% Update handles structure
guidata(hObject, handles);

RunCicle(hObject, eventdata, handles);

return;

%---------------------------------------------------%
function EditP10_Callback(hObject, eventdata, handles)
%---------------------------------------------------%

handles.P(2,1) = str2num(get(handles.EditP10, 'String'));
handles.P(2,2) = 1 - handles.P(2,1);
set(handles.EditP11, 'String', num2str(handles.P(2,2)));

% Update handles structure
guidata(hObject, handles);

RunCicle(hObject, eventdata, handles);

return;

%----------------------------------------------------%
function EditP11_Callback(hObject, eventdata, handles)
%----------------------------------------------------%

handles.P(2,2) = str2num(get(handles.EditP11, 'String'));
handles.P(2,1) = 1 - handles.P(2,2);
set(handles.EditP10, 'String', num2str(handles.P(2,1)));

% Update handles structure
guidata(hObject, handles);

RunCicle(hObject, eventdata, handles);

return;

%--------------------------------------------------------%
function EditLambda0_Callback(hObject, eventdata, handles)
%--------------------------------------------------------%

handles.lambda0 = str2num(get(handles.EditLambda0, 'String'));

% Update handles structure
guidata(hObject, handles);

RunCicle(hObject, eventdata, handles);

return;

%--------------------------------------------------------%
function EditLambda1_Callback(hObject, eventdata, handles)
%--------------------------------------------------------%

handles.lambda1 = str2num(get(handles.EditLambda1, 'String'));

% Update handles structure
guidata(hObject, handles);

RunCicle(hObject, eventdata, handles);

return;


%---------------------------------------------%
function RunCicle(hObject, eventdata, handles);
%---------------------------------------------%

Nbuffer = 8;


P = handles.P;

AniSpeed = handles.AniSpeed;

lambda0 = handles.lambda0;
lambda1 = handles.lambda1;

u = SteadyProbability(P);

set(handles.LabelSSP0, 'String', num2str(u(1)));
set(handles.LabelSSP1, 'String', num2str(u(2)));




state = binornd(1, u(2));





state_Buffer = zeros(1, 2*Nbuffer);
tk_Buffer = [];
Ntk_Buffer = zeros(1, Nbuffer);


while(1)
    
    [state, lambda] = UpdateState(state, P, lambda0, lambda1);
    tk = GeneratePositions(lambda);

    state_Buffer(1:2) = [];
    state_Buffer = [state_Buffer state state];
    
    tk_Buffer(1:Ntk_Buffer(1)) = [];
    tk_Buffer = [tk_Buffer-1 tk+Nbuffer-1];
    
    Ntk_Buffer(1) = [];
    Ntk_Buffer = [Ntk_Buffer length(tk)];
    
    
    set(gcf, 'CurrentAxes', handles.AxesNeuralSig); 
    plot(round(0:1/2:Nbuffer-1/2), state_Buffer, 'r', 'linewidth', 4); hold on;
    stem(tk_Buffer, 2/3*ones(sum(Ntk_Buffer),1), 'k', 'filled', 'Marker', '^', 'MarkerSize', 5);
    axis([0 Nbuffer 0 1]); hold off; axis off;
    
    
    
    pause(1-AniSpeed);
    
    
    if ~get(handles.ButtonStartStop, 'Value')
        break;
    end
    
end

