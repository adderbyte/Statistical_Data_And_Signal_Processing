function tk = GeneratePositions(lambda);

% Delete this
tk = 0:0.2:1;

return;